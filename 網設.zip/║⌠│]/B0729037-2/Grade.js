function loadGrades() 
		{
		   	var length = localStorage.length;
			var markup = "<table border='1'>"+
			"<tr><td>StudentId</td>"+
			"<td>Physics</td>"+
			"<td>Calculus</td>"+
			"<td>Discrete Math</td>"+
			"<td>Average</td>"+
			"<td>Action</td></tr>";
			for (var i = 0 ; i < localStorage.length ; i++) 
			{
				if ( localStorage.key(i) == localStorage[localStorage.key(i)] &&
					 localStorage.key(i) != '' )
				{
					markup += "<tr>" +
							"<td>" + localStorage[localStorage.key(i)] + "</td>" +
							"<td>" + localStorage[localStorage.key(i)+'Physics'] + "</td>" +
							"<td>" + localStorage[localStorage.key(i)+'Calculus'] + "</td>" +
							"<td>" + localStorage[localStorage.key(i)+'Discretemath'] + "</td>" + 
							"<td>" + 
							(parseInt(localStorage[localStorage.key(i)+'Physics'])+
							 parseInt(localStorage[localStorage.key(i)+'Calculus'])+
							 parseInt(localStorage[localStorage.key(i)+'Discretemath']) ) / 3 + "</td>" + 
							"<td>" + "<input id = '" + localStorage.key(i) + 
							"' type = 'button' value = 'Delete' onclick = 'deleteTag(id)'></td>" + 
							"</tr>" ;
				}
			}
			markup += "</table>";
			document.getElementById("searches").innerHTML = markup;
		}
function EnterGrade() 
{
   localStorage[StudentId.value] = StudentId.value ;
   localStorage[StudentId.value+'Physics'] = Physics.value ;
   localStorage[StudentId.value+'Calculus'] = Calculus.value ;
   localStorage[StudentId.value+'Discretemath'] = Discretemath.value ;
  
   StudentId.value = ""; 
   Physics.value = ""; 
   Calculus.value ="";
   Discretemath.value ="";
   loadGrades(); // reload searches
} 
// deletes a specific key-value pair from localStorage
function deleteTag( StudentId ) 
{
   localStorage.removeItem( StudentId);
   localStorage.removeItem( StudentId+'Physics' );
   localStorage.removeItem( StudentId+'Calculus' );
   localStorage.removeItem( StudentId+'Discretemath' );
   localStorage.removeItem( StudentId+'Average' );
   localStorage.removeItem(StudentId+' Action ');
   loadGrades(); // reload searches
} // end function deleteTag

// display existing tagged query for editing


// register event handlers then load searches
function start()
{
   var EnterButton = document.getElementById( "EnterButton" );
   EnterButton.addEventListener( "click", EnterGrade, false );
   loadGrades();
} // end function start

window.addEventListener( "load", start, false );