var letters="abcdefghijklmnopqrstuvwxyzabcdefghijklm";
	  
	  function  buttonPressed()
	  {
		var inputField=document.getElementById("inputField");
		
		document.getElementById("results").innerHTML=
			"<p>Frist occurrence is located at index"+letters.indexOf(inputField.value)+"</p>"+
			"<p>Last occurrence is located at index"+letters.lastIndexOf(inputField.value)+"</p>"+
			"<p>First occurrence from index 12 is located at index"+letters.indexOf(inputField.value,12)+"</p>"+
			"<p>Last occurrence from index 12 is located at index"+letters.lastIndexOf(inputField.value,12)+"</p>"+
			"<p>The number of occurrences of substring is "+(letters.split(inputField.value).length-1)+"</p>";
	  }
	  function  start()
	  {
		var searchbutton=document.getElementById("searchButton");
		searchbutton.addEventListener("click",buttonPressed,false);
	  }
	  window.addEventListener("load",start,false);